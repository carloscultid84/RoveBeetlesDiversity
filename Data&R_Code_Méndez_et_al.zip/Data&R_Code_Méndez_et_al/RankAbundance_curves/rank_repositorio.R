source("Patch-way the working directory to call subrutine DetAbu.R")
source("Patch-way the working directory to call subrutine DetAbu.R")
source("Patch-way the working directory to call subrutine DetAbu.R")

x<-read.csv("cafetales.csv", header = T, sep=";")

#BOS
data.frame(x)
FOR<-data.frame(x)[,"FOR"]
FOR
out1 <- SpecDist(FOR, "abundance")
summary(out1)
out1
out1 <- subset(out1, probability>0)
out1
par(mfrow=c(1,4)) 
plot(out1$probability, col=ifelse(out1$method=="detected",1,2),pch=16, xlab="Species Rank", ylab="Relative Abundance", ylim=c(0.0, 0.15), xlim=c(0, 100), main="FOR")

##POLI
PSC<-data.frame(x)[,"PSC"]
out2 <- SpecDist(PSC, "abundance")
summary(out2)
out2 <- subset(out2, probability>0)
out2
plot(out2$probability, col=ifelse(out2$method=="detected",1,2),pch=16, xlab="Species Rank", ylab="Relative Abundance",  ylim=c(0.0, 0.15), xlim=c(0, 100), main="PSC",)

##MONO
MSC<-data.frame(x)[,"MSC"]
MSC
out3 <- SpecDist(MSC, "abundance")
summary(out3)
out3 <- subset(out3, probability>0)
out3
plot(out3$probability, col=ifelse(out3$method=="detected",1,2),pch=16, xlab="Species Rank", ylab="Relative Abundance", ylim=c(0.0, 0.15), xlim=c(0, 50), main="MSC",)

##SOL
SGC<-data.frame(x)[,"SGC"]
SGC
out4 <- SpecDist(SGC, "abundance")
summary(out4)
out4 <- subset(out4, probability>0)
out4
plot(out4$probability, col=ifelse(out4$method=="detected",1,2),pch=16, xlab="Species Rank", ylab="Relative Abundance",  ylim=c(0.0, 0.15), xlim=c(0, 40), main="SGC",)
