library(vegan)

setwd("C:\\Users\\DIANA\\Documents\\An�lisis R\\StaphCafetales")
a <- read.csv("staphy.csv", header = T, sep = ";")
b <- read.csv("vambientales.csv", header = T, sep = ";")

categ<-read.csv("categ.csv", header = T, sep = ";")
categ
c<-cbind(b,categ)
c

#An?lisis DIRECTO CCA
##********************************************
a.cca<-cca(a~.,b)
a.cca
summary(a.cca)
anova(a.cca) 
#anova para comparar los ejes con 500 permutaciones
anova(a.cca,by="axis",perm.max=500)
#anova q permita mirar cual de las variables q modela las respuestas de las spp
anova(a.cca, by="terms",permu=500)

#Diferecia entre FACTORES
#******************************

sp.ca<-cca(a~.,b)
a.factores<-envfit(sp.ca,categ,permutations=999)
plot(sp.ca, scaling=2, type= "p")
with(categ,ordiellipse(sp.ca,Habitat,kind="se",conf=0.70))
with(categ,ordispider(sp.ca,Habitat,col="blue",lty=2))
with(categ,ordihull(sp.ca,Habitat,col="blue",label=T))
