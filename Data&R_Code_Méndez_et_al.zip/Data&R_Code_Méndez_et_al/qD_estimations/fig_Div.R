#################Scripts and data used to Méndez-Rojas et al. BITR-21-148#################
######Inputs to figure 2

######Packages

install.packages("coin")
install.packages("gvlma")

library(iNEXT)
library(ggplot2)
library(ggpubr)
library(reshape2)

library(coin)
library(survival)
library(sandwich)
library(gvlma)

#####Estimations of the qD per land-use 

#@tableS3 is the data set to make the qD estimations [row = UTRs, columns = land-use; in same order that showed in Table S3]. sep = "^t"

g1 <- read.table("tableS3.csv", header = T)

di <- DataInfo(g1)###Summary table that is use to identify the sample coverage per land-use and endpoint. The Sc to comparison was 82.63%. 
ep <- max(di$n)### maximum endpoint to qD estimations (See Cultid-Medina & Escobar 2019).

out=iNEXT(g1, q=c(0, 1, 2), datatype="abundance", endpoint=ep, knots = 120, nboot = 1000)

out$iNextEst ###  sheet with qD estimations per land-use.
write.table(out$iNextEst, "out_g1.txt") ###Table used to make the "results.csv" table regarding the SC = 82.63%.

####Load table to make the Figure 2

tp <- read.csv("results.csv", header = T, sep=";")
tplot <- tp[,c(1,2,6,7)] 
colnames(tplot) <- c("Zone", "qD", "Value", "Li")

tplot$range <- tplot$Value - tplot$Li  
tplot$Zone <- factor(tplot$Zone, levels = c("FOR", "PSC", "MSC", "SGC"))

pd <- position_dodge(0.1) 

tp <- ggplot(tplot, aes(x = Zone, y = Value, shape = factor(qD), group = qD))+
  geom_errorbar(aes(ymin=Value-range, ymax=Value+range), width =.1, colour="black")+
  geom_point(size = 3)+
  geom_line(lty = 2, size = 0.2)+
  theme_classic()+
  xlab("Land use")+
  ylab("Effective number of species")+
  theme(axis.text.x = element_text(color = "black", size = 12, face = "plain"))+
  theme(axis.text.y = element_text(color = "black", size = 12, face = "plain"))+
  theme(text=element_text(size=12, family = "TT Times New Roman", face = "bold"))+
  theme(panel.background=element_rect(fill="transparent",color="black",size=1))

q0 <- expression(" "^0*"D")
q1 <- expression(" "^1*"D")
q2 <- expression(" "^2*"D")

f2B <- tp + theme(legend.position = c(0.85, 0.85))+
  theme(legend.title = element_blank())+
  scale_shape_discrete(label = c(q0, q1, q2))+
  theme(legend.text = element_text(colour = "black", size = 12, family = "TT Times New Roman"))+
  guides(shape = guide_legend(override.aes = list(size = 4)))

ggsave("fig2.jpeg", width = 10, height = 10, units = "cm", dpi = 300)
